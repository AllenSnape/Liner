// 静态常量代号
const CODE_UNKNOWN_ERROR = -1;
const CODE_INIT = 0;